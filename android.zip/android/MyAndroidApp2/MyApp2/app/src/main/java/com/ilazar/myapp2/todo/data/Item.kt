package com.ilazar.myapp2.todo.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "songs")
data class Song(
    @PrimaryKey @ColumnInfo(name = "_id") val _id: String,
    @ColumnInfo(name = "title") var title: String,
    @ColumnInfo(name = "artist") var artist: String,
    @ColumnInfo(name = "duration") var duration: Int  // duration in seconds
) {
    override fun toString(): String = "$title - $artist"
}

// Keep Item as a type alias for backward compatibility during refactoring
typealias Item = Song
