package com.ilazar.myapp2.todo.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.ilazar.myapp2.todo.data.Song

@Dao
interface SongDao {
    @Query("SELECT * from songs ORDER BY title ASC")
    fun getAll(): LiveData<List<Song>>

    @Query("SELECT * FROM songs WHERE _id=:id ")
    fun getById(id: String): LiveData<Song>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(song: Song)

    @Update(onConflict = OnConflictStrategy.REPLACE)
    suspend fun update(song: Song)

    @Query("DELETE FROM songs")
    suspend fun deleteAll()
}

// Keep ItemDao as a type alias for backward compatibility
typealias ItemDao = SongDao