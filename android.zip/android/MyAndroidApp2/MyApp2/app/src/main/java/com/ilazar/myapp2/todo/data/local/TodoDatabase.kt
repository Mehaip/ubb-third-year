package com.ilazar.myapp2.todo.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.ilazar.myapp2.todo.data.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Song::class], version = 2)
abstract class MusicDatabase : RoomDatabase() {

    abstract fun songDao(): SongDao

    companion object {
        @Volatile
        private var INSTANCE: MusicDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): MusicDatabase {
            val inst = INSTANCE
            if (inst != null) {
                return inst
            }
            val instance =
                Room.databaseBuilder(
                    context.applicationContext,
                    MusicDatabase::class.java,
                    "music_db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(MusicDatabaseCallback(scope))
                    .build()
            INSTANCE = instance
            return instance
        }

        private class MusicDatabaseCallback(private val scope: CoroutineScope) :
            RoomDatabase.Callback() {

            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateDatabase(database.songDao())
                    }
                }
            }
        }

        suspend fun populateDatabase(songDao: SongDao) {
//            songDao.deleteAll()
//            val song = Song("1", "Sample Song", "Sample Artist", 180)
//            songDao.insert(song)
        }
    }

}

// Keep TodoDatabase as a type alias for backward compatibility
typealias TodoDatabase = MusicDatabase
typealias ItemDao = SongDao
