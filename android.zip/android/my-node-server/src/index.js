const Koa = require('koa');
const app = new Koa();
const server = require('http').createServer(app.callback());
const WebSocket = require('ws');
const wss = new WebSocket.Server({ server });
const Router = require('koa-router');
const cors = require('koa-cors');
const bodyparser = require('koa-bodyparser');

app.use(bodyparser());
app.use(cors());
app.use(async (ctx, next) => {
  const start = new Date();
  await next();
  const ms = new Date() - start;
  console.log(`${ctx.method} ${ctx.url} ${ctx.response.status} - ${ms}ms`);
});

app.use(async (ctx, next) => {
  await new Promise(resolve => setTimeout(resolve, 2000));
  await next();
});

app.use(async (ctx, next) => {
  try {
    await next();
  } catch (err) {
    ctx.response.body = { issue: [{ error: err.message || 'Unexpected error' }] };
    ctx.response.status = 500;
  }
});

class Song {
  constructor({ id, title, artist, duration, date, version }) {
    this.id = id;
    this.title = title;
    this.artist = artist;
    this.duration = duration; // duration in seconds
    this.date = date;
    this.version = version;
  }
}

const songs = [];
for (let i = 0; i < 3; i++) {
  songs.push(new Song({
    id: `${i}`,
    title: `Song ${i}`,
    artist: `Artist ${i}`,
    duration: 180 + i * 30,
    date: new Date(Date.now() + i),
    version: 1
  }));
}
let lastUpdated = songs[songs.length - 1].date;
let lastId = songs[songs.length - 1].id;
const pageSize = 10;

const broadcast = data =>
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(data));
    }
  });

const router = new Router();

router.get('/item', ctx => {
  const ifModifiedSince = ctx.request.get('If-Modified-Since');
  if (ifModifiedSince && new Date(ifModifiedSince).getTime() >= lastUpdated.getTime() - lastUpdated.getMilliseconds()) {
    ctx.response.status = 304; // NOT MODIFIED
    return;
  }
  const title = ctx.request.query.title;
  const page = parseInt(ctx.request.query.page) || 1;
  ctx.response.set('Last-Modified', lastUpdated.toUTCString());
  const sortedSongs = songs
    .filter(song => title ? song.title.indexOf(title) !== -1 : true)
    .sort((n1, n2) => -(n1.date.getTime() - n2.date.getTime()));
  const offset = (page - 1) * pageSize;
  // ctx.response.body = {
  //   page,
  //   songs: sortedSongs.slice(offset, offset + pageSize),
  //   more: offset + pageSize < sortedSongs.length
  // };
  ctx.response.body = songs;
  ctx.response.status = 200;
});

router.get('/item/:id', async (ctx) => {
  const songId = ctx.request.params.id;
  const song = songs.find(song => songId === song.id);
  if (song) {
    ctx.response.body = song;
    ctx.response.status = 200; // ok
  } else {
    ctx.response.body = { issue: [{ warning: `song with id ${songId} not found` }] };
    ctx.response.status = 404; // NOT FOUND (if you know the resource was deleted, then return 410 GONE)
  }
});

const createSong = async (ctx) => {
  const song = ctx.request.body;
  if (!song.title) { // validation
    ctx.response.body = { issue: [{ error: 'Title is missing' }] };
    ctx.response.status = 400; //  BAD REQUEST
    return;
  }
  if (!song.artist) {
    ctx.response.body = { issue: [{ error: 'Artist is missing' }] };
    ctx.response.status = 400; //  BAD REQUEST
    return;
  }
  if (!song.duration) {
    ctx.response.body = { issue: [{ error: 'Duration is missing' }] };
    ctx.response.status = 400; //  BAD REQUEST
    return;
  }
  song.id = `${parseInt(lastId) + 1}`;
  lastId = song.id;
  song.date = new Date();
  song.version = 1;
  songs.push(song);
  ctx.response.body = song;
  ctx.response.status = 201; // CREATED
  broadcast({ event: 'created', payload: { song } });
};

router.post('/item', async (ctx) => {
  await createSong(ctx);
});

router.put('/item/:id', async (ctx) => {
  const id = ctx.params.id;
  const song = ctx.request.body;
  song.date = new Date();
  const songId = song.id;
  if (songId && id !== song.id) {
    ctx.response.body = { issue: [{ error: `Param id and body id should be the same` }] };
    ctx.response.status = 400; // BAD REQUEST
    return;
  }
  if (!songId) {
    await createSong(ctx);
    return;
  }
  const index = songs.findIndex(song => song.id === id);
  if (index === -1) {
    ctx.response.body = { issue: [{ error: `song with id ${id} not found` }] };
    ctx.response.status = 400; // BAD REQUEST
    return;
  }
  const songVersion = parseInt(ctx.request.get('ETag')) || song.version;
  if (songVersion < songs[index].version) {
    ctx.response.body = { issue: [{ error: `Version conflict` }] };
    ctx.response.status = 409; // CONFLICT
    return;
  }
  song.version++;
  songs[index] = song;
  lastUpdated = new Date();
  ctx.response.body = song;
  ctx.response.status = 200; // OK
  broadcast({ event: 'updated', payload: { song } });
});

router.del('/item/:id', ctx => {
  const id = ctx.params.id;
  const index = songs.findIndex(song => id === song.id);
  if (index !== -1) {
    const song = songs[index];
    songs.splice(index, 1);
    lastUpdated = new Date();
    broadcast({ event: 'deleted', payload: { song } });
  }
  ctx.response.status = 204; // no content
});

setInterval(() => {
  lastUpdated = new Date();
  lastId = `${parseInt(lastId) + 1}`;
  const song = new Song({
    id: lastId,
    title: `Song ${lastId}`,
    artist: `Artist ${lastId}`,
    duration: 180 + Math.floor(Math.random() * 120),
    date: lastUpdated,
    version: 1
  });
  songs.push(song);
  console.log(`Added new song: ${song.title} by ${song.artist}`);
  broadcast({ event: 'created', payload: { song } });
}, 150000);

app.use(router.routes());
app.use(router.allowedMethods());

server.listen(3000);
